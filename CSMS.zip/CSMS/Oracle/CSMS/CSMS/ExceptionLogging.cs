﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

namespace CSMS
{
    public class ExceptionLogging
    {
        public static void WriteLog(Exception ex, string methodName)
        {
            StreamWriter sw = null;
            string folderPath = HttpContext.Current.Server.MapPath("~/LogFiles/");
            string filePath = folderPath + "LogFile_" + System.DateTime.Today.ToString("ddMMyyyy") + ".txt";

            string message = string.Format("Error occurred on : {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            //message += string.Format("Method Name :  {0}", MethodBase.GetCurrentMethod().Name);
            message += string.Format("Method Name :  {0}", methodName);
            message += Environment.NewLine;
            message += string.Format("Error Message: {0}", ex.Message);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", ex.StackTrace);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", ex.Source);
            message += Environment.NewLine;
            message += string.Format("TargetSite: {0}", ex.TargetSite.ToString());
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            try
            {
                if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }
                if (!File.Exists(filePath)) { File.Create(filePath).Close(); }

                sw = new StreamWriter(filePath, true);
                sw.WriteLine(message);
            }
            catch (Exception exx) { }
            finally { if (sw != null) { sw.Flush(); sw.Close(); } }
        }

        public static void WriteLog(string message)
        {
            StreamWriter sw = null;
            string folderPath = HttpContext.Current.Server.MapPath("~/LogFiles/");
            string filePath = folderPath + "LogFile_" + System.DateTime.Today.ToString("ddMMyyyy") + ".txt";
            try
            {
                if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }
                if (!File.Exists(filePath)) { File.Create(filePath).Close(); }

                sw = new StreamWriter(filePath, true);
                sw.WriteLine("-----------------------------------------------------------");
                sw.WriteLine(message);
                sw.WriteLine("-----------------------------------------------------------");
                sw.WriteLine(Environment.NewLine);
            }
            catch (Exception ex) { }
            finally { if (sw != null) { sw.Flush(); sw.Close(); } }
        }
    }
}
