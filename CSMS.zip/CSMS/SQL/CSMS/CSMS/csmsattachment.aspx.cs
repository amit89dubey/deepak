﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OracleClient;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Reflection;
using System.Threading;

namespace CSMS
{
    public partial class _Default : System.Web.UI.Page
    {
        string srid = string.Empty;
        private SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["srid"] != null)
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(Request.QueryString["srid"])))
                    {
                        srid = Convert.ToString(Request.QueryString["srid"]);
                        if (!IsPostBack)
                        {
                            BindGrid(srid);
                        }
                    }
                }
            }
        }

        private void BindGrid(string srid)
        {
            string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            try
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = @"SELECT SR_ATTACHMENT_ID,
                                       SERVICE_REQUEST_ID,RN_FILE_ATTACHMENT_FN,
                                       RN_FILE_ATTACHMENT_FZ,RN_FILE_ATTACHMENT_EX 
                                       FROM TBL_FILES WHERE SERVICE_REQUEST_ID = @SERVICE_REQUEST_ID";
                        cmd.Parameters.AddWithValue("@SERVICE_REQUEST_ID", srid);
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            cmd.Connection = con;
                            adapter.SelectCommand = cmd;
                            using (DataTable dt = new DataTable())
                            {
                                adapter.Fill(dt);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    gvCSMSAttachments.DataSource = dt;
                                    gvCSMSAttachments.DataBind();
                                }
                                else
                                {
                                    gvCSMSAttachments.DataSource = null;
                                    gvCSMSAttachments.DataBind();
                                }
                            }
                        }

                        //cmd.Connection = con;
                        //if (con.State != ConnectionState.Open)
                        //    con.Open();

                        //OracleDataReader reader = cmd.ExecuteReader();
                        //if (reader.HasRows)
                        //{
                        //    gvCSMSAttachments.DataSource = reader;
                        //    gvCSMSAttachments.DataBind();
                        //}
                        //else
                        //{
                        //    DataTable dt = new DataTable();
                        //    gvCSMSAttachments.DataSource = new string[] { };
                        //    gvCSMSAttachments.DataBind();
                        //}
                        //con.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.WriteLog(ex, MethodBase.GetCurrentMethod().Name.ToString());
                //ExceptionLogging.WriteLog("Error occurred on " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + ", Method Name : " + MethodBase.GetCurrentMethod().Name + " , Error message : " + ex.Message);
                AlertBox("Oops something went wrong. Please try after sometime.");
            }
            finally { if (con.State != ConnectionState.Closed) { con.Close(); } }
        }

//        protected void Upload(object sender, EventArgs e)
//        {
//            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
//            string contentType = FileUpload1.PostedFile.ContentType;
//            string fileExtension = System.IO.Path.GetExtension(filename).ToLower();
//            using (Stream fs = FileUpload1.PostedFile.InputStream)
//            {
//                using (BinaryReader br = new BinaryReader(fs))
//                {
//                    byte[] bytes = br.ReadBytes((Int32)fs.Length);
//                    string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
//                    using (SqlConnection con = new SqlConnection(constr))
//                    {
//                        string query = @"INSERT INTO tbl_Files values 
//                                        (@SR_ATTACHMENT_ID, @RN_DESCRIPTOR, @RN_CREATE_DATE, @RN_CREATE_USER, 
//                                         @RN_EDIT_DATE, @RN_EDIT_USER, @SERVICE_REQUEST_ID, @FILE_ATTACHMENT, 
//                                         @RN_FILE_ATTACHMENT_DE, @RN_FILE_ATTACHMENT_FN, @RN_FILE_ATTACHMENT_FZ, 
//                                         @RN_FILE_ATTACHMENT_ED, @RN_FILE_ATTACHMENT_ET, @RN_FILE_ATTACHMENT_EX, 
//                                         @CREATE_USER_ID, @CREATE_DATE, @CREATE_USER_NAME, @DELETE_USER_ID, 
//                                         @DELETE_USER_NAME, @DELETE_DATE, @IS_OUTWARD)";
//                        using (SqlCommand cmd = new SqlCommand(query))
//                        {
//                            cmd.Connection = con;
//                            cmd.Parameters.AddWithValue("@SR_ATTACHMENT_ID", "00000000001EBA7N");
//                            cmd.Parameters.AddWithValue("@RN_DESCRIPTOR", "6/25/2018 6:26:57 PM: WEBHOOK.PDF");
//                            cmd.Parameters.AddWithValue("@RN_CREATE_DATE", DateTime.Now);
//                            cmd.Parameters.AddWithValue("@RN_CREATE_USER", "00000000000047E6");
//                            cmd.Parameters.AddWithValue("@RN_EDIT_DATE", DateTime.Now);
//                            cmd.Parameters.AddWithValue("@RN_EDIT_USER", "00000000000047E6");
//                            cmd.Parameters.AddWithValue("@SERVICE_REQUEST_ID", "0000000000FFDDF9");
//                            cmd.Parameters.AddWithValue("@FILE_ATTACHMENT", bytes);
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_DE", filename);
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_FN", filename);
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_FZ", "30468");
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_ED", DateTime.Now);
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_ET", DateTime.Now);
//                            cmd.Parameters.AddWithValue("@RN_FILE_ATTACHMENT_EX", fileExtension);
//                            cmd.Parameters.AddWithValue("@CREATE_USER_ID", "00000000000047E6");
//                            cmd.Parameters.AddWithValue("@CREATE_DATE", DateTime.Now);
//                            cmd.Parameters.AddWithValue("@CREATE_USER_NAME", "0000000000004D2F");
//                            cmd.Parameters.AddWithValue("@DELETE_USER_ID", string.Empty);
//                            cmd.Parameters.AddWithValue("@DELETE_USER_NAME", string.Empty);
//                            cmd.Parameters.AddWithValue("@DELETE_DATE", string.Empty);
//                            cmd.Parameters.AddWithValue("@IS_OUTWARD", string.Empty);
//                            con.Open();
//                            cmd.ExecuteNonQuery();
//                            con.Close();
//                        }
//                    }
//                }
//            }
//            Response.Redirect(Request.Url.AbsoluteUri);
//        }

        protected void DownloadFile(object sender, EventArgs e)
        {
            try
            {
                string SR_ATTACHMENT_ID = ((sender as LinkButton).CommandArgument);
                byte[] bytes;
                string fileName, contentType;
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = @"SELECT RN_FILE_ATTACHMENT_FN,FILE_ATTACHMENT,RN_FILE_ATTACHMENT_EX 
                                        FROM TBL_FILES WHERE SR_ATTACHMENT_ID = @SR_ATTACHMENT_ID";
                        cmd.Parameters.AddWithValue("@SR_ATTACHMENT_ID", SR_ATTACHMENT_ID);
                        cmd.Connection = con;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {
                            sdr.Read();
                            bytes = (byte[])sdr["FILE_ATTACHMENT"];
                            fileName = sdr["RN_FILE_ATTACHMENT_FN"].ToString();
                            contentType = GetMimeType(fileName);
                        }
                        con.Close();
                    }
                }
                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = contentType;
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
                Response.BinaryWrite(bytes);
                Response.Flush();
                Response.End();
                //HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (ThreadAbortException er) { }
            catch (Exception ex)
            {
                ExceptionLogging.WriteLog(ex, MethodBase.GetCurrentMethod().Name.ToString());
                //ExceptionLogging.WriteLog("Error occurred on " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + ", Method Name : " + MethodBase.GetCurrentMethod().Name + " , Error message : " + ex.Message);
                AlertBox("Oops something went wrong. Please try after sometime.");
            }
            finally { if (con.State == ConnectionState.Open) { con.Close(); } }
        }

        private string GetMimeType(string fileName)
        {
            string mimeType = "application/unknown";
            try
            {
                string fileExtension = System.IO.Path.GetExtension(fileName).ToLower();
                Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(fileExtension);
                if (regKey != null && regKey.GetValue("Content Type") != null)
                    mimeType = regKey.GetValue("Content Type").ToString();
            }
            catch (Exception ex)
            {
                ExceptionLogging.WriteLog(ex, MethodBase.GetCurrentMethod().Name.ToString());
                //ExceptionLogging.WriteLog("Error occurred on " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + ", Method Name : " + MethodBase.GetCurrentMethod().Name + " , Error message : " + ex.Message);
            }
            return mimeType;
        }

        protected void gvCSMSAttachments_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCSMSAttachments.PageIndex = e.NewPageIndex;
            BindGrid(srid);
        }

        private void AlertBox(string message)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }
    }
}
